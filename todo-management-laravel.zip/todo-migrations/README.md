# Todo Management System — Backend Laravel

Sistem Todo dengan reminder Telegram menggunakan Laravel + PostgreSQL + Redis + Laravel Horizon.

---

## Stack

| Komponen     | Teknologi                     |
|--------------|-------------------------------|
| Backend      | Laravel 11 (PHP 8.2+)         |
| Database     | PostgreSQL 15+                |
| Queue/Cache  | Redis 7+                      |
| Queue Worker | **Laravel Horizon** (free, open source) |
| Reminder     | Telegram Bot API (gratis)     |

> **Mengapa Laravel Horizon?**
> Horizon adalah dashboard monitoring queue resmi dari Laravel.
> Free, open source, berjalan di atas Redis, support retry, failed jobs,
> metrics throughput — tidak perlu bayar lisensi apapun.

---

## Instalasi

### 1. Clone & install dependency

```bash
composer require laravel/horizon
php artisan horizon:install
```

### 2. Setup database

```bash
# Copy .env
cp .env.example .env
php artisan key:generate

# Edit .env — isi DB_* dan REDIS_* dan TELEGRAM_BOT_TOKEN

# Jalankan semua migrations
php artisan migrate

# (Opsional) Seed data awal
php artisan db:seed
```

### 3. Setup Telegram Bot

1. Buka Telegram, chat ke **@BotFather**
2. Ketik `/newbot`, ikuti instruksi, simpan token
3. Masukkan token ke `.env`: `TELEGRAM_BOT_TOKEN=xxx`
4. User perlu menghubungkan akun:
   - Buka bot di Telegram, klik Start
   - Sistem menyimpan `telegram_chat_id` ke tabel `users`

### 4. Jalankan Queue Worker (Laravel Horizon)

```bash
# Development
php artisan horizon

# Production (gunakan Supervisor)
# /etc/supervisor/conf.d/horizon.conf:
#
# [program:horizon]
# process_name=%(program_name)s
# command=php /var/www/artisan horizon
# autostart=true
# autorestart=true
# user=www-data
# redirect_stderr=true
# stdout_logfile=/var/www/storage/logs/horizon.log
```

Akses dashboard Horizon: `http://localhost/horizon`

### 5. Aktifkan Scheduler (sekali di crontab)

```bash
# Tambahkan ke crontab server (crontab -e)
* * * * * cd /var/www && php artisan schedule:run >> /dev/null 2>&1
```

Scheduler akan menjalankan `reminders:dispatch` setiap menit otomatis.

---

## Alur Kerja Reminder

```
User buat Todo (due_date + reminder ON)
        ↓
Record di tabel reminders dibuat
remind_at = due_date - offset_minutes
        ↓
Scheduler (setiap 1 menit)
php artisan reminders:dispatch
        ↓
Cek: is_enabled=true & is_sent=false & remind_at <= now()
        ↓
Dispatch SendTelegramReminderJob → Redis queue 'reminders'
        ↓
Horizon Worker mengeksekusi job
        ↓
TelegramService::sendMessage(chat_id, pesan)
        ↓
Update reminders: is_sent=true, sent_at=now()
Insert notification_logs: status=sent
```

---

## Struktur Tabel

| Tabel              | Fungsi                                      |
|--------------------|---------------------------------------------|
| users              | Data user + telegram_chat_id                |
| groups             | Kategori/kelompok todo                      |
| labels             | Label warna untuk todo                      |
| todos              | Todo utama                                  |
| sub_tasks          | Sub-task dalam sebuah todo                  |
| todo_label         | Pivot many-to-many todo ↔ label             |
| milestones         | Milestone/project jangka panjang            |
| **reminders**      | Konfigurasi reminder per-todo (inti sistem) |
| notification_logs  | Log semua pengiriman notifikasi             |
| jobs               | Laravel Queue jobs (fallback)               |
| failed_jobs        | Jobs yang gagal dieksekusi                  |

---

## Config Horizon (config/horizon.php)

```php
'environments' => [
    'production' => [
        'supervisor-1' => [
            'connection' => 'redis',
            'queue'      => ['reminders', 'default'],
            'balance'    => 'auto',
            'processes'  => 5,
            'tries'      => 3,
        ],
    ],
    'local' => [
        'supervisor-1' => [
            'connection' => 'redis',
            'queue'      => ['reminders', 'default'],
            'balance'    => 'simple',
            'processes'  => 3,
            'tries'      => 3,
        ],
    ],
],
```

---

## Menambah Channel Baru (Email/WhatsApp)

1. Tambah value di enum `channel` di migration reminders (atau buat migration alter)
2. Buat `SendEmailReminderJob` / `SendWhatsAppReminderJob`
3. Tambah case di `DispatchDueReminders::handle()`
4. Kolom `channel` di tabel `reminders` sudah siap menampung multi-channel
