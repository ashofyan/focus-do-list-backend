<?php

namespace App\Jobs;

use App\Models\Reminder;
use App\Models\NotificationLog;
use App\Services\TelegramService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class SendTelegramReminderJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Maksimum percobaan ulang jika gagal.
     */
    public int $tries = 3;

    /**
     * Delay antar retry (detik): 60s, 300s, 900s
     */
    public array $backoff = [60, 300, 900];

    /**
     * Timeout job dalam detik.
     */
    public int $timeout = 30;

    public function __construct(
        public readonly int $reminderId
    ) {}

    public function handle(TelegramService $telegram): void
    {
        $reminder = Reminder::with(['todo', 'user'])->find($this->reminderId);

        if (! $reminder) {
            Log::warning("Reminder #{$this->reminderId} tidak ditemukan.");
            return;
        }

        // Skip jika sudah terkirim atau dimatikan
        if ($reminder->is_sent || ! $reminder->is_enabled) {
            return;
        }

        $user = $reminder->user;
        $todo = $reminder->todo;

        // Pastikan user sudah connect Telegram
        if (! $user->telegram_chat_id) {
            $this->logNotification($reminder, 'skipped', null, 'User belum connect Telegram');
            return;
        }

        $message = $this->buildMessage($todo, $reminder);

        try {
            $result = $telegram->sendMessage($user->telegram_chat_id, $message);

            // Update reminder sebagai terkirim
            $reminder->update([
                'is_sent'   => true,
                'sent_at'   => now(),
                'last_error' => null,
            ]);

            $this->logNotification(
                $reminder,
                'sent',
                $message,
                null,
                $result['message_id'] ?? null
            );
        } catch (\Throwable $e) {
            $reminder->increment('retry_count');
            $reminder->update(['last_error' => $e->getMessage()]);

            $this->logNotification($reminder, 'failed', $message, $e->getMessage());

            Log::error("Gagal kirim Telegram reminder #{$reminder->id}: {$e->getMessage()}");

            // Re-throw agar Laravel Queue menangani retry
            throw $e;
        }
    }

    private function buildMessage($todo, $reminder): string
    {
        $dueText = $todo->due_date
            ? '⏰ Due: ' . $todo->due_date->setTimezone($reminder->user->timezone)->format('d M Y, H:i')
            : '';

        $priority = match ($todo->priority) {
            'high'   => '🔴 Tinggi',
            'medium' => '🟡 Sedang',
            'low'    => '🟢 Rendah',
            default  => '',
        };

        return implode("\n", array_filter([
            "📌 *Pengingat Todo*",
            "",
            "📝 {$todo->title}",
            $todo->description ? "📄 {$todo->description}" : null,
            $dueText,
            $priority ? "Prioritas: {$priority}" : null,
            "",
            "✅ Selesaikan sekarang di aplikasi Todo Anda.",
        ]));
    }

    private function logNotification(
        Reminder $reminder,
        string $status,
        ?string $message,
        ?string $error,
        ?string $externalId = null
    ): void {
        NotificationLog::create([
            'reminder_id'         => $reminder->id,
            'user_id'             => $reminder->user_id,
            'channel'             => 'telegram',
            'status'              => $status,
            'message_preview'     => $message ? substr($message, 0, 500) : null,
            'external_message_id' => $externalId,
            'error_message'       => $error,
            'sent_at'             => now(),
        ]);
    }
}
