<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes;

    protected $fillable = [
        'name',
        'email',
        'password',
        'telegram_chat_id',
        'telegram_username',
        'telegram_connected',
        'timezone',
        'avatar',
    ];

    protected $hidden = [
        'password',
        'remember_token',
        'telegram_chat_id', // jangan expose langsung ke response
    ];

    protected $casts = [
        'email_verified_at'  => 'datetime',
        'telegram_connected' => 'boolean',
        'password'           => 'hashed',
    ];

    // -------------------------------------------------------------------------
    // Relations
    // -------------------------------------------------------------------------

    public function todos(): HasMany
    {
        return $this->hasMany(Todo::class);
    }

    public function groups(): HasMany
    {
        return $this->hasMany(Group::class);
    }

    public function labels(): HasMany
    {
        return $this->hasMany(Label::class);
    }

    public function milestones(): HasMany
    {
        return $this->hasMany(Milestone::class);
    }

    public function reminders(): HasMany
    {
        return $this->hasMany(Reminder::class);
    }

    public function notificationLogs(): HasMany
    {
        return $this->hasMany(NotificationLog::class);
    }
}
