<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Reminder extends Model
{
    protected $fillable = [
        'todo_id',
        'user_id',
        'is_enabled',
        'channel',
        'remind_at',
        'offset_minutes',
        'is_sent',
        'sent_at',
        'retry_count',
        'last_error',
    ];

    protected $casts = [
        'is_enabled'     => 'boolean',
        'is_sent'        => 'boolean',
        'remind_at'      => 'datetime',
        'sent_at'        => 'datetime',
        'offset_minutes' => 'integer',
        'retry_count'    => 'integer',
    ];

    // -------------------------------------------------------------------------
    // Relations
    // -------------------------------------------------------------------------

    public function todo(): BelongsTo
    {
        return $this->belongsTo(Todo::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function notificationLogs(): HasMany
    {
        return $this->hasMany(NotificationLog::class);
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    /**
     * Hitung ulang remind_at berdasarkan due_date todo dan offset_minutes.
     * Dipanggil saat todo due_date diperbarui.
     */
    public function recalculateRemindAt(): void
    {
        if ($this->todo?->due_date) {
            $this->remind_at = $this->todo->due_date->subMinutes($this->offset_minutes);
            $this->is_sent   = false; // reset agar bisa dikirim ulang
            $this->save();
        }
    }

    /**
     * Nonaktifkan reminder tanpa menghapus konfigurasi.
     */
    public function disable(): void
    {
        $this->update(['is_enabled' => false]);
    }

    /**
     * Aktifkan kembali reminder.
     */
    public function enable(): void
    {
        $this->update([
            'is_enabled' => true,
            'is_sent'    => false,
        ]);
    }
}
