<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Reminder;
use App\Models\Todo;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ReminderController extends Controller
{
    // -------------------------------------------------------------------------
    // GET /api/todos/{id}/reminder
    // Ambil konfigurasi reminder untuk sebuah todo
    // -------------------------------------------------------------------------
    public function show(Request $request, int $id): JsonResponse
    {
        $todo = Todo::where('user_id', $request->user()->id)->findOrFail($id);

        $reminder = $todo->reminder;

        if (! $reminder) {
            return response()->json([
                'data'    => null,
                'message' => 'Reminder belum dikonfigurasi untuk todo ini.',
            ]);
        }

        return response()->json(['data' => $this->reminderResource($reminder)]);
    }

    // -------------------------------------------------------------------------
    // POST /api/todos/{id}/reminder
    // Buat atau update reminder (upsert)
    // Jika reminder sudah ada → update; jika belum → buat baru
    // -------------------------------------------------------------------------
    public function upsert(Request $request, int $id): JsonResponse
    {
        $todo = Todo::where('user_id', $request->user()->id)->findOrFail($id);

        // Validasi: wajib ada due_date di todo agar reminder bisa dihitung
        if (! $todo->due_date) {
            return response()->json([
                'message' => 'Todo harus memiliki due date sebelum bisa menambahkan reminder.',
            ], 422);
        }

        $data = $request->validate([
            'is_enabled'     => 'required|boolean',
            'channel'        => 'required|in:telegram,email,whatsapp',
            'offset_minutes' => 'required|integer|min:0|max:10080', // max 7 hari = 10080 menit
        ]);

        // Validasi: user harus sudah connect Telegram jika channel telegram
        if ($data['channel'] === 'telegram' && ! $request->user()->telegram_chat_id) {
            return response()->json([
                'message' => 'Anda belum menghubungkan akun Telegram. Silakan connect Telegram terlebih dahulu.',
            ], 422);
        }

        // Hitung waktu reminder
        $remindAt = $todo->due_date->copy()->subMinutes($data['offset_minutes']);

        // Cegah reminder di masa lalu
        if ($remindAt->isPast() && $data['is_enabled']) {
            return response()->json([
                'message' => "Waktu reminder sudah lewat. Kurangi offset atau ubah due date todo.",
            ], 422);
        }

        $reminder = Reminder::updateOrCreate(
            [
                'todo_id' => $todo->id,
                'channel' => $data['channel'],
            ],
            [
                'user_id'        => $request->user()->id,
                'is_enabled'     => $data['is_enabled'],
                'offset_minutes' => $data['offset_minutes'],
                'remind_at'      => $remindAt,
                'is_sent'        => false, // reset agar bisa dikirim ulang
                'sent_at'        => null,
                'retry_count'    => 0,
                'last_error'     => null,
            ]
        );

        $status = $reminder->wasRecentlyCreated ? 'dibuat' : 'diperbarui';

        return response()->json([
            'message' => "Reminder berhasil {$status}.",
            'data'    => $this->reminderResource($reminder),
        ], $reminder->wasRecentlyCreated ? 201 : 200);
    }

    // -------------------------------------------------------------------------
    // PATCH /api/todos/{id}/reminder/toggle
    // Toggle ON/OFF tanpa mengubah konfigurasi lainnya
    // -------------------------------------------------------------------------
    public function toggle(Request $request, int $id): JsonResponse
    {
        $todo = Todo::where('user_id', $request->user()->id)->findOrFail($id);

        $reminder = Reminder::where('todo_id', $todo->id)->firstOrFail();

        $newState = ! $reminder->is_enabled;
        $reminder->update([
            'is_enabled' => $newState,
            // Jika diaktifkan kembali, reset status sent agar bisa kirim lagi
            'is_sent'    => $newState ? false : $reminder->is_sent,
        ]);

        return response()->json([
            'message'    => $newState ? 'Reminder diaktifkan.' : 'Reminder dinonaktifkan.',
            'is_enabled' => $newState,
            'data'       => $this->reminderResource($reminder->fresh()),
        ]);
    }

    // -------------------------------------------------------------------------
    // DELETE /api/todos/{id}/reminder
    // Hapus reminder (user memilih "Tanpa Reminder")
    // -------------------------------------------------------------------------
    public function destroy(Request $request, int $id): JsonResponse
    {
        $todo = Todo::where('user_id', $request->user()->id)->findOrFail($id);

        $deleted = Reminder::where('todo_id', $todo->id)->delete();

        if (! $deleted) {
            return response()->json(['message' => 'Reminder tidak ditemukan.'], 404);
        }

        return response()->json(['message' => 'Reminder dihapus. Todo ini tidak akan mengirim pengingat.']);
    }

    // -------------------------------------------------------------------------
    // Helper: Format response reminder
    // -------------------------------------------------------------------------
    private function reminderResource(Reminder $reminder): array
    {
        return [
            'id'             => $reminder->id,
            'todo_id'        => $reminder->todo_id,
            'is_enabled'     => $reminder->is_enabled,
            'channel'        => $reminder->channel,
            'offset_minutes' => $reminder->offset_minutes,
            'remind_at'      => $reminder->remind_at?->toISOString(),
            'is_sent'        => $reminder->is_sent,
            'sent_at'        => $reminder->sent_at?->toISOString(),
            'retry_count'    => $reminder->retry_count,
            'last_error'     => $reminder->last_error,
            'created_at'     => $reminder->created_at->toISOString(),
            'updated_at'     => $reminder->updated_at->toISOString(),
        ];
    }
}
