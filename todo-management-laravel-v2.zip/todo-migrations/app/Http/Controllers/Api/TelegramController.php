<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\TelegramService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class TelegramController extends Controller
{
    public function __construct(private readonly TelegramService $telegram) {}

    // -------------------------------------------------------------------------
    // GET /api/telegram/status
    // Cek apakah user sudah menghubungkan akun Telegram
    // -------------------------------------------------------------------------
    public function status(Request $request): JsonResponse
    {
        $user = $request->user();

        return response()->json([
            'connected'          => $user->telegram_connected,
            'telegram_username'  => $user->telegram_username,
            'telegram_chat_id'   => $user->telegram_chat_id ? '***' . substr($user->telegram_chat_id, -4) : null,
        ]);
    }

    // -------------------------------------------------------------------------
    // POST /api/telegram/connect
    // User menginput chat_id Telegram mereka secara manual
    //
    // Cara user mendapat chat_id:
    // 1. User buka bot di Telegram → klik Start
    // 2. Bot membalas dengan chat_id mereka (via webhook)
    // 3. User copy-paste chat_id ke form di aplikasi
    // -------------------------------------------------------------------------
    public function connect(Request $request): JsonResponse
    {
        $data = $request->validate([
            'chat_id'  => 'required|string',
            'username' => 'nullable|string|max:100',
        ]);

        $user = $request->user();

        // Cek apakah chat_id sudah dipakai user lain
        $existing = \App\Models\User::where('telegram_chat_id', $data['chat_id'])
            ->where('id', '!=', $user->id)
            ->exists();

        if ($existing) {
            return response()->json([
                'message' => 'Chat ID ini sudah terhubung ke akun lain.',
            ], 422);
        }

        // Kirim pesan selamat datang dulu untuk verifikasi
        try {
            $this->telegram->sendWelcome($data['chat_id'], $user->name);
        } catch (\Throwable $e) {
            return response()->json([
                'message' => 'Gagal mengirim pesan ke Telegram. Pastikan chat_id benar dan bot sudah di-start.',
                'error'   => $e->getMessage(),
            ], 422);
        }

        $user->update([
            'telegram_chat_id'   => $data['chat_id'],
            'telegram_username'  => $data['username'] ?? null,
            'telegram_connected' => true,
        ]);

        return response()->json([
            'message' => 'Telegram berhasil dihubungkan! Cek pesan di Telegram Anda.',
        ]);
    }

    // -------------------------------------------------------------------------
    // DELETE /api/telegram/disconnect
    // -------------------------------------------------------------------------
    public function disconnect(Request $request): JsonResponse
    {
        $request->user()->update([
            'telegram_chat_id'   => null,
            'telegram_username'  => null,
            'telegram_connected' => false,
        ]);

        return response()->json(['message' => 'Telegram berhasil diputus.']);
    }

    // -------------------------------------------------------------------------
    // POST /api/telegram/test
    // Kirim pesan test untuk memastikan koneksi berfungsi
    // -------------------------------------------------------------------------
    public function sendTest(Request $request): JsonResponse
    {
        $user = $request->user();

        if (! $user->telegram_chat_id) {
            return response()->json([
                'message' => 'Telegram belum terhubung.',
            ], 422);
        }

        try {
            $this->telegram->sendMessage(
                $user->telegram_chat_id,
                "🧪 *Pesan Test*\n\nKoneksi Telegram Anda berfungsi dengan baik! ✅\n\nAnda akan menerima reminder di sini."
            );

            return response()->json(['message' => 'Pesan test berhasil dikirim ke Telegram!']);
        } catch (\Throwable $e) {
            return response()->json([
                'message' => 'Gagal kirim pesan test: ' . $e->getMessage(),
            ], 500);
        }
    }

    // -------------------------------------------------------------------------
    // POST /api/telegram/webhook
    // Dipanggil oleh server Telegram ketika user mengirim pesan ke bot
    // Setup webhook: GET https://api.telegram.org/bot{TOKEN}/setWebhook?url=https://yourdomain.com/api/telegram/webhook
    // -------------------------------------------------------------------------
    public function webhook(Request $request): JsonResponse
    {
        $body = $request->all();

        Log::info('Telegram webhook received', $body);

        // Handle pesan /start dari user
        $message = $body['message'] ?? null;
        if (! $message) {
            return response()->json(['ok' => true]);
        }

        $chatId   = $message['chat']['id'] ?? null;
        $text     = $message['text'] ?? '';
        $username = $message['from']['username'] ?? null;
        $name     = $message['from']['first_name'] ?? 'User';

        if ($chatId && str_starts_with($text, '/start')) {
            try {
                $this->telegram->sendMessage(
                    (string) $chatId,
                    implode("\n", [
                        "👋 Halo *{$name}*!",
                        "",
                        "Selamat datang di *Todo Manager Bot*.",
                        "",
                        "Chat ID Anda: `{$chatId}`",
                        "",
                        "Salin chat ID di atas dan paste ke halaman *Pengaturan Telegram* di aplikasi untuk menghubungkan akun Anda.",
                    ])
                );
            } catch (\Throwable $e) {
                Log::error('Webhook sendMessage error: ' . $e->getMessage());
            }
        }

        return response()->json(['ok' => true]);
    }
}
