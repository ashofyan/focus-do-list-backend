<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class TelegramService
{
    private string $baseUrl;
    private string $token;

    public function __construct()
    {
        $this->token  = config('services.telegram.bot_token');
        $this->baseUrl = "https://api.telegram.org/bot{$this->token}";
    }

    /**
     * Kirim pesan teks ke Telegram chat.
     *
     * @throws \RuntimeException jika Telegram API mengembalikan error
     */
    public function sendMessage(string $chatId, string $text, array $options = []): array
    {
        $payload = array_merge([
            'chat_id'    => $chatId,
            'text'       => $text,
            'parse_mode' => 'Markdown',
        ], $options);

        $response = Http::timeout(15)->post("{$this->baseUrl}/sendMessage", $payload);

        if (! $response->successful() || ! $response->json('ok')) {
            $error = $response->json('description', 'Unknown Telegram error');
            throw new \RuntimeException("Telegram API error: {$error}");
        }

        return $response->json('result');
    }

    /**
     * Verifikasi bahwa bot token valid.
     */
    public function validateBot(): bool
    {
        try {
            $response = Http::timeout(10)->get("{$this->baseUrl}/getMe");
            return $response->successful() && $response->json('ok');
        } catch (\Throwable) {
            return false;
        }
    }

    /**
     * Kirim pesan sambutan saat user connect Telegram.
     */
    public function sendWelcome(string $chatId, string $userName): array
    {
        $message = implode("\n", [
            "👋 Halo *{$userName}*!",
            "",
            "Telegram Anda sudah terhubung ke *Todo Manager*.",
            "Anda akan menerima pengingat task di sini. ✅",
            "",
            "Ketik /help untuk melihat perintah yang tersedia.",
        ]);

        return $this->sendMessage($chatId, $message);
    }
}
