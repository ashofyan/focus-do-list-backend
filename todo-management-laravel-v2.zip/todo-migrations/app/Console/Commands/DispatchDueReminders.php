<?php

namespace App\Console\Commands;

use App\Jobs\SendTelegramReminderJob;
use App\Models\Reminder;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class DispatchDueReminders extends Command
{
    /**
     * Jalankan setiap menit via Laravel Scheduler.
     * Tambahkan di app/Console/Kernel.php (atau routes/console.php Laravel 11+):
     *
     *   Schedule::command('reminders:dispatch')->everyMinute()->withoutOverlapping();
     *
     * Atau di bootstrap/app.php (Laravel 11):
     *   ->withSchedule(function (Schedule $schedule) {
     *       $schedule->command('reminders:dispatch')->everyMinute()->withoutOverlapping();
     *   })
     */
    protected $signature   = 'reminders:dispatch';
    protected $description = 'Dispatch semua reminder yang sudah jatuh tempo ke queue';

    public function handle(): int
    {
        $now = now();

        // Ambil semua reminder yang:
        // - is_enabled = true
        // - is_sent = false
        // - remind_at <= sekarang
        // - retry_count < 3
        $reminders = Reminder::query()
            ->where('is_enabled', true)
            ->where('is_sent', false)
            ->where('remind_at', '<=', $now)
            ->where('retry_count', '<', 3)
            ->select('id', 'channel')
            ->get();

        if ($reminders->isEmpty()) {
            $this->line('Tidak ada reminder yang perlu dikirim.');
            return self::SUCCESS;
        }

        $dispatched = 0;

        foreach ($reminders as $reminder) {
            match ($reminder->channel) {
                'telegram' => SendTelegramReminderJob::dispatch($reminder->id)
                                  ->onQueue('reminders'),
                // 'email'     => SendEmailReminderJob::dispatch($reminder->id)->onQueue('reminders'),
                // 'whatsapp'  => SendWhatsAppReminderJob::dispatch($reminder->id)->onQueue('reminders'),
                default => null,
            };

            $dispatched++;
        }

        $this->info("✅ {$dispatched} reminder di-dispatch ke queue.");
        Log::info("DispatchDueReminders: {$dispatched} jobs dispatched.");

        return self::SUCCESS;
    }
}
