<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name', 100);
            $table->string('email')->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');

            // Telegram integration
            $table->string('telegram_chat_id')->nullable()->unique();
            $table->string('telegram_username')->nullable();
            $table->boolean('telegram_connected')->default(false);

            // User preferences
            $table->string('timezone', 50)->default('UTC');
            $table->string('avatar')->nullable();

            $table->rememberToken();
            $table->timestamps();
            $table->softDeletes();

            $table->index('email');
            $table->index('telegram_chat_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};
