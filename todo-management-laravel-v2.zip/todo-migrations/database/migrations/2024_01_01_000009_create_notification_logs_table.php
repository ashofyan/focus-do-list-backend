<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('notification_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('reminder_id')->constrained('reminders')->cascadeOnDelete();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();

            $table->string('channel', 20); // telegram, email, whatsapp
            $table->enum('status', ['sent', 'failed', 'skipped'])->default('sent');

            // Isi pesan yang dikirim (preview 500 char)
            $table->string('message_preview', 500)->nullable();

            // Telegram message_id untuk tracking (opsional)
            $table->string('external_message_id')->nullable();

            // Jika gagal, simpan error-nya
            $table->text('error_message')->nullable();

            $table->dateTime('sent_at');
            $table->timestamps();

            $table->index('reminder_id');
            $table->index('user_id');
            $table->index(['user_id', 'status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('notification_logs');
    }
};
