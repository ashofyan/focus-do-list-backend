<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Tabel reminders menyimpan konfigurasi reminder per-todo.
     *
     * Alur kerja:
     * 1. User membuat/update todo dengan reminder ON  → record ini dibuat
     * 2. Command/Scheduler Laravel mengecek remind_at <= now() setiap menit
     * 3. Jika is_sent = false → dispatch TelegramReminderJob ke Redis queue
     * 4. Job mengirim pesan ke Telegram lalu update is_sent = true & sent_at
     *
     * Jika reminder OFF (is_enabled = false) → record tetap ada tapi tidak diproses
     */
    public function up(): void
    {
        Schema::create('reminders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('todo_id')->constrained('todos')->cascadeOnDelete();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();

            // Toggle ON/OFF reminder (tanpa menghapus konfigurasi)
            $table->boolean('is_enabled')->default(true);

            // Channel pengiriman — saat ini hanya telegram, bisa diperluas nanti
            $table->enum('channel', ['telegram', 'email', 'whatsapp'])->default('telegram');

            // Waktu reminder dikirim (dihitung: due_date - offset_minutes)
            $table->dateTime('remind_at');

            // Berapa menit sebelum due_date reminder dikirim (default 15 menit)
            $table->unsignedSmallInteger('offset_minutes')->default(15);

            // Status pengiriman
            $table->boolean('is_sent')->default(false);
            $table->dateTime('sent_at')->nullable();

            // Untuk pengiriman ulang jika gagal
            $table->unsignedTinyInteger('retry_count')->default(0);
            $table->text('last_error')->nullable();

            $table->timestamps();

            // Indexes untuk query scheduler
            $table->index(['is_enabled', 'is_sent', 'remind_at']); // query utama scheduler
            $table->index('todo_id');
            $table->index('user_id');

            // Satu todo hanya boleh punya satu reminder per channel
            $table->unique(['todo_id', 'channel']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('reminders');
    }
};
