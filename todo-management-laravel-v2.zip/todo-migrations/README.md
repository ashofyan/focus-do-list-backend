# Todo Management System — Backend Laravel

Sistem Todo dengan reminder Telegram menggunakan Laravel + PostgreSQL + Redis.

---

## Stack

| Komponen     | Teknologi                          |
|--------------|------------------------------------|
| Backend      | Laravel 11 (PHP 8.2+)              |
| Database     | PostgreSQL 15+                     |
| Queue/Cache  | Redis 7+                           |
| Queue Worker | `php artisan queue:work` (built-in)|
| Reminder     | Telegram Bot API (gratis)          |

> **Mengapa tidak pakai Horizon?**
> Laravel Horizon membutuhkan Supervisor (Linux-only) dan tidak bisa
> dijalankan di Windows / lokal biasa. Untuk lokal dan production
> skala kecil-menengah, `php artisan queue:work` sudah lebih dari cukup.

---

## Cara Jalankan Lokal (3 Terminal)

```bash
# Terminal 1 — Web server
php artisan serve

# Terminal 2 — Queue worker
php artisan queue:work redis --queue=reminders,default --tries=3 --backoff=60

# Terminal 3 — Scheduler (pengganti crontab di lokal)
php artisan schedule:work
```

---

## Instalasi

```bash
composer install
cp .env.example .env
php artisan key:generate
# edit .env (DB, Redis, Telegram token)
php artisan migrate
```

---

## Setup Telegram Bot

1. Chat @BotFather di Telegram → /newbot → copy token
2. Set di .env: `TELEGRAM_BOT_TOKEN=xxx`
3. User connect via endpoint: `POST /api/telegram/connect`

---

## Alur Reminder

```
Buat Todo + reminder ON
    → insert ke tabel reminders (remind_at = due_date - offset_minutes)
    → Scheduler tiap menit: php artisan reminders:dispatch
    → cek remind_at <= now() & is_sent=false
    → dispatch SendTelegramReminderJob ke Redis queue
    → Worker eksekusi job → kirim Telegram
    → update is_sent=true, insert notification_logs
```

---

## Production (Linux)

Gunakan Supervisor untuk menjaga `queue:work` tetap hidup:

```ini
[program:todo-queue]
command=php /var/www/artisan queue:work redis --queue=reminders,default --tries=3 --max-time=3600
autostart=true
autorestart=true
numprocs=2
user=www-data
stdout_logfile=/var/www/storage/logs/queue.log
```

Crontab:
```
* * * * * cd /var/www && php artisan schedule:run >> /dev/null 2>&1
```
